<?php $error=''; $route=pxcore::Route(); $all=pxcore::getDoctors(); $id=pxcore::getId(); 
if(isset($_POST['adddoctor'])):
	$error=pxcore::addNewDoctor([
		'postData'=>$_POST,
		'loc'=>$route
	]);
endif;
if(isset($_POST['updatedoctor'])):
	$error=pxcore::updateDoctor([
		'postData'=>$_POST,
		'loc'=>$route,
		'updateId'=>$id
	]);
endif;
 if(!empty($error)): ?> <div class="alert alert-danger" role="alert"><?=$error?></div><?php endif;
 switch(pxcore::subPage()): case 'addnew':  ?>
<div class="row">
<div class="col-12 mt-3">
<h3>Add New Doctor</h3>
<form class="row g-3" action="" method="post">
  <div class="col-auto">
    <label for="doctorname" class="visually-hidden">Doctor Name</label>
    <input type="text" class="form-control" id="doctorname" name="doctorname" value="<?=!empty($_POST['doctorname'])?$_POST['doctorname']:''?>" <?=pxcore::addHTML5ValidationMsg('Please enter doctor name')?>>
  </div>  
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3" name="adddoctor">Add Doctor</button>
  </div>
</form>
</div>
</div>
<?php break; case 'update': if(!empty($id)): $single=pxcore::getSingleDoctor($id); ?>
<div class="row">
<div class="col-12 mt-3">
<h3>Update Doctor</h3>
<form class="row g-3" action="" method="post">
  <div class="col-auto">
    <label for="doctorname" class="visually-hidden">Doctor Name</label>
    <input type="text" class="form-control" id="doctorname" name="doctorname" value="<?=!empty($_POST['doctorname'])?$_POST['doctorname']:$single['doctor_name']?>" <?=pxcore::addHTML5ValidationMsg('Please enter doctor name')?>>
  </div>  
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3" name="updatedoctor">Update Doctor</button>
  </div>
</form>
</div>
</div>
<?php else: pxcore::_GoTo($route); endif; break; default: ?>
<div class="row">
<div class="col-12">
<a class="btn btn-success mt-3 float-end" href="<?=$route.pxcore::createSubPage('addnew')?>">Add New</a>
</div>
<div class="col-12">
<div class="table-responsive">
<table class="table">
  <thead>
    <tr>
		<th scope="col">#</th>     
		<th scope="col">Doctor Name</th>  
		<th scope="col" class="float-end">Actions</th> 
    </tr>
  </thead>
  <tbody>
	<?php if(!empty($all)): foreach($all as $key => $value):?>
    <tr>
      <th scope="row"><?=($key+1)?></th>
      <td><?=$value['doctor_name']?></td>
	  <td class="float-end"><a class="btn btn-success" href="<?=$route.pxcore::createSubPage('update').pxcore::createId($value['id'])?>">Update</a></td>
    </tr>    
	<?php endforeach; else: ?>
	<tr><td>No data found</td></tr>
	<?php endif; ?>
  </tbody>
</table>
</div>
</div>
</div>
<?php endswitch; ?>