<?php $error=''; $route=pxcore::Route(); $all=pxcore::getPatients(); $id=pxcore::getId(); 
if(isset($_POST['addpatient'])):
	$error=pxcore::addNewPatient([
		'postData'=>$_POST,
		'loc'=>pxcore::site_url()
	]);
endif;
if(isset($_POST['updatepatient'])):
	$error=pxcore::updatePatient([
		'postData'=>$_POST,
		'loc'=>pxcore::site_url(),
		'updateId'=>$id
	]);
endif;
 if(!empty($error)): ?> <div class="alert alert-danger" role="alert"><?=$error?></div><?php endif;
 switch(pxcore::subPage()): case 'addnew':  ?>
<div class="row">
<div class="col-12 mt-3">
<h3>Add New Patient</h3>
<form class="row g-3" action="" method="post">
  <div class="col-auto">
    <label for="patientname" class="visually-hidden">Patient Name</label>
    <input type="text" class="form-control" id="patientname" name="patientname" value="<?=!empty($_POST['patientname'])?$_POST['patientname']:''?>" <?=pxcore::addHTML5ValidationMsg('Please enter patient name')?>>
  </div>  
  <div class="col-auto">
    <label for="patientname" class="visually-hidden">Patient Name</label>
    <input type="text" class="form-control" id="testname" name="testname" value="<?=!empty($_POST['testname'])?$_POST['testname']:''?>" <?=pxcore::addHTML5ValidationMsg('Please enter test name')?>>
  </div>
  <!--<div class="col-auto">
    <label for="doctorname" class="visually-hidden">Doctor Name</label>
    <select class="form-control" id="doctorname" name="doctorname" <?=pxcore::addHTML5ValidationMsg('Please enter doctor name')?>><?=pxcore::getDoctorsList(['selected'=>!empty($_POST['doctorname'])?$_POST['doctorname']:''])?></select>
  </div>-->
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3" name="addpatient">Add Patient</button>
  </div>
</form>
</div>
</div>
<?php break; case 'update': if(!empty($id)): $single=pxcore::getSinglePatient($id); ?>
<div class="row">
<div class="col-12 mt-3">
<h3>Update Patient</h3>
<form class="row g-3" action="" method="post">
  <div class="col-auto">
    <label for="patientname" class="visually-hidden">Patient Name</label>
    <input type="text" class="form-control" id="patientname" name="patientname" value="<?=!empty($_POST['patientname'])?$_POST['patientname']:$single['patient_name']?>" <?=pxcore::addHTML5ValidationMsg('Please enter patient name')?>>
  </div>
	<div class="col-auto">
    <label for="patientname" class="visually-hidden">Patient Name</label>
    <input type="text" class="form-control" id="testname" name="testname" value="<?=!empty($_POST['testname'])?$_POST['testname']:$single['test_type']?>" <?=pxcore::addHTML5ValidationMsg('Please enter test name')?>>
  </div>
  <!--<div class="col-auto">
    <label for="doctorname" class="visually-hidden">Doctor Name</label>
    <select class="form-control" id="doctorname" name="doctorname" <?=pxcore::addHTML5ValidationMsg('Please enter doctor name')?>><?=pxcore::getDoctorsList(['selected'=>!empty($_POST['doctorname'])?$_POST['doctorname']:$single['doctor']])?></select>
  </div>  -->
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3" name="updatepatient">Update Patient</button>
  </div>
</form>
</div>
</div>
<?php else: pxcore::_GoTo($route); endif; break; default: ?>
<div class="row">
<div class="col-12">
<a class="btn btn-success mt-3 float-end" href="<?=$route.pxcore::createSubPage('addnew')?>">Add New</a>
</div>
<div class="col-12">
<div class="table-responsive">
<table class="table">
  <thead>
    <tr>
		<th scope="col">Patient Id</th>     
		<th scope="col">Patient Name</th>
		<th scope="col">Test Type</th>  
		<th scope="col" class="float-end">Actions</th> 
    </tr>
  </thead>
  <tbody>
	<?php if(!empty($all)): foreach($all as $key => $value):?>
    <tr>
      <th scope="row"><?=($key+1)?></th>
	  <td><?=$value['patient_name']?></td>
      <td><?=$value['test_type']?></td>
	  <td class="float-end"><a class="btn btn-success" href="<?=$route.pxcore::createSubPage('update').pxcore::createId($value['id'])?>">Update</a></td>
    </tr>    
	<?php endforeach; else: ?>
	<tr><td>No data found</td></tr>
	<?php endif; ?>
  </tbody>
</table>
</div>
</div>
</div>
<?php endswitch; ?>