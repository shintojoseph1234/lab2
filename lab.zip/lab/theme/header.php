<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?=ucwords(pxcore::getHospitalName())?></title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
<style>

</style>
	</head>
	<body>
	<div class="container">
		<div class="row mt-3">
			<div class="col-12">
				<h3><?=ucwords(pxcore::getHospitalName())?></h3>
				<ul class="nav nav-tabs">
					<?=pxcore::getMenu()?>
				</ul>
			</div>
		</div>
		
	