<?php $error=''; $route=pxcore::Route(); $all=pxcore::getOpreations(); $id=pxcore::getId(); 
if(isset($_POST['addopreation'])):
	$error=pxcore::addNewOpreation([
		'postData'=>$_POST,
		'loc'=>$route
	]);
endif;
if(isset($_POST['updateopreation'])):
	$error=pxcore::updateOpreation([
		'postData'=>$_POST,
		'loc'=>$route,
		'updateId'=>$id
	]);
endif;
 if(!empty($error)): ?> <div class="alert alert-danger" role="alert"><?=$error?></div><?php endif;
 switch(pxcore::subPage()): case 'addnew':  ?>
<div class="row">
<div class="col-12 mt-3">
<h3>Add New Opreation</h3>
<form class="row g-3" action="" method="post">
  <div class="col-auto">
    <label for="opreationname" class="visually-hidden">Opreationname Type</label>
    <input type="text" class="form-control" id="opreationname" name="opreationname" value="<?=!empty($_POST['opreationname'])?$_POST['opreationname']:''?>" <?=pxcore::addHTML5ValidationMsg('Please enter opreation type or name')?>>
  </div>  
  <div class="col-auto">
    <label for="patientname" class="visually-hidden">Patient Name</label>
    <select class="form-control" id="patientname" name="patientname" <?=pxcore::addHTML5ValidationMsg('Please select patient name')?>><?=pxcore::getPatientsList(['selected'=>!empty($_POST['patientname'])?$_POST['patientname']:''])?></select>
  </div>
  <div class="col-auto">
    <label for="doctorname" class="visually-hidden">Doctor Name</label>
    <select class="form-control" id="doctorname" name="doctorname" <?=pxcore::addHTML5ValidationMsg('Please select doctor name')?>><?=pxcore::getDoctorsList(['selected'=>!empty($_POST['doctorname'])?$_POST['doctorname']:''])?></select>
  </div>
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3" name="addopreation">Add Opreation</button>
  </div>
</form>
</div>
</div>
<?php break; case 'update': if(!empty($id)): $single=pxcore::getSingleOpreation($id);  ?>
<div class="row">
<div class="col-12 mt-3">
<h3>Update Opreation</h3>
<form class="row g-3" action="" method="post">
  <div class="col-auto">
    <label for="opreationname" class="visually-hidden">Opreationname Type</label>
    <input type="text" class="form-control" id="opreationname" name="opreationname" value="<?=!empty($_POST['opreationname'])?$_POST['opreationname']:$single['opration_name']?>" <?=pxcore::addHTML5ValidationMsg('Please enter opreation type or name')?>>
  </div>  
  <div class="col-auto">
    <label for="patientname" class="visually-hidden">Patient Name</label>
    <select class="form-control" id="patientname" name="patientname" <?=pxcore::addHTML5ValidationMsg('Please select patient name')?>><?=pxcore::getPatientsList(['selected'=>!empty($_POST['patientname'])?$_POST['patientname']:$single['patient']])?></select>
  </div> 
  <div class="col-auto">
    <label for="doctorname" class="visually-hidden">Doctor Name</label>
    <select class="form-control" id="doctorname" name="doctorname" <?=pxcore::addHTML5ValidationMsg('Please enter doctor name')?>><?=pxcore::getDoctorsList(['selected'=>!empty($_POST['doctorname'])?$_POST['doctorname']:$single['doctor']])?></select>
  </div>  
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3" name="updateopreation">Update Opreation</button>
  </div>
</form>
</div>
</div>
<?php else: pxcore::_GoTo($route); endif; break; default: ?>
<div class="row">
<div class="col-12">
<a class="btn btn-success mt-3 float-end" href="<?=$route.pxcore::createSubPage('addnew')?>">Add New</a>
</div>
<div class="col-12">
<div class="table-responsive">
<table class="table">
  <thead>
    <tr>
		<th scope="col">#</th>     
		<th scope="col">Patient Name</th>
		<th scope="col">Doctor Name</th>  
		<th scope="col">Opration</th>  
		<th scope="col" class="float-end">Actions</th> 
    </tr>
  </thead>
  <tbody>
	<?php if(!empty($all)): foreach($all as $key => $value):?>
    <tr>
      <th scope="row"><?=($key+1)?></th>
	  <td><?=pxcore::getSinglePatient($value['patient'],'patient_name')?></td>
      <td><?=pxcore::getSingleDoctor($value['doctor'],'doctor_name')?></td>
	  <td><?=$value['opration_name']?></td>
	  <td class="float-end"><a class="btn btn-success" href="<?=$route.pxcore::createSubPage('update').pxcore::createId($value['id'])?>">Update</a></td>
    </tr>    
	<?php endforeach; else: ?>
	<tr><td>No data found</td></tr>
	<?php endif; ?>
  </tbody>
</table>
</div>
</div>
</div>
<?php endswitch; ?>