<?php
ob_start(); ob_flush();
ini_set("display_errors" , "1");
ini_set("log_errors" ,"1");
ini_set("error_log" , "Errors.log.txt");
date_default_timezone_set("Asia/Kolkata");
if(!defined('APPLICATION_PATH')) define('APPLICATION_PATH', realpath('./'));
if(!defined('LIBS_PATH'))  define('LIBS_PATH', realpath('./libs'));
if(!defined('THEME_PATH'))  define('THEME_PATH', realpath('./theme'));
set_include_path(implode(PATH_SEPARATOR,[APPLICATION_PATH,LIBS_PATH,THEME_PATH,get_include_path()]));
spl_autoload_register(function($class){ $class=str_replace('\\','/',$class); require_once $class.'.php'; });
pxcore::loadsite();