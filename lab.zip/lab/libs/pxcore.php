<?php
class pxcore{
		
	//database related query functions
	public static function get_data($table=false,$where=false,$extra=false,$selectfld=false){            
		$con=new dbfuns(); return $con->get_result($table,$where,$extra,$selectfld);
	}
	public static function set_data($fun=false,$table=false,$fields=false,$where=false){		
		$scon=new dbfuns(); return $scon->set_result($fun,$table,$fields,$where);
	}	
	 public static function addHTML5ValidationMsg($args=false, $type=false){
        if(!empty($args)):
            $req=empty($type)?'required':'';
            return 'oninvalid="this.setCustomValidity(\''.$args.'\')" oninput="this.setCustomValidity(\'\')" '.$req;
        endif;
    }
	public static function printRData($args=false){
            if(!empty($args)):
                echo '<pre>'; print_r($args); echo '</pre>'; echo "\n";
            endif;
        }
        public static function ValidateAlphaNumaric($args=false){
            if(!empty($args)):
                if(preg_match('/^[a-zA-Z]+[a-zA-Z0-9._]+$/', $args)):
                    return '';
                else:
                    return $args;
                endif;
            endif;
        }
        public static function validateAlphaNumwithSpace($args=false){
            if(!empty($args)):
                if(preg_match("/^[a-zA-Z0-9\s]+$/",$args)):
                    return '';
                else:
                    return $args;
                endif;
            endif;
        }
        public static function validateAlphawithSpace($args=false){
            if(!empty($args)):
                if(preg_match("/^[a-zA-Z\s]+$/",$args)):
                    return '';
                else:
                    return $args;
                endif;
            endif;
        }
        public static function validateAlpha($args=false){
            if(!empty($args)):
                if(preg_match("/^[a-zA-Z]+$/",$args)):
                    return '';
                else:
                    return $args;
                endif;
            endif;
        }
        public static function validateMobileNo($args=false){
            if(!empty($args)):
                if(preg_match("/^([0-9]{10})?$/", $args)):
                    return '';
                else:
                    return $args;
                endif;
            endif;
        }
        public static function validatePassword($args=false){
            if(!empty($args)):
               // if(preg_match("/^([0-9a-zA-Z_-$#.@8&]{6,20})?$/", $args)):
                if(strlen($args) > 5 and strlen($args) <= 20):
                    return '';
                else:
                    return 'Please enter password min 6 and max 20 characters';
                endif;
            endif;
        }
    public static function set_custom($sql=false){ $scon=new dbfuns(); return $scon->set_custom($sql); }	
	public static function get_custom($sql=false){ $scon=new dbfuns(); return $scon->get_custom($sql); }
	public static function del_data($table=false,$where=false){ $dcon=new dbfuns($dbname); return $dcon->delete_record($table,$where); }	
	public static function real_string($str=false,$table=false){	$con=new dbfuns(); return $con->real_string($str); }
	public static function ErrorMsg($val=false){ echo "<script>alert('".$val."');</script>"; }
	public static function _GoTo($val=false){ echo "<script> window.location='".$val."'; </script>"; }
	public static function site_url(){ $server=!empty($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:'localhost'; return 'http://'.$server.'/'; }
	public static function Route(){ return !empty($_GET['route'])?$_GET['route']:''; }
	public static function subPage(){ return !empty($_GET['subpage'])?$_GET['subpage']:''; }
	public static function createSubPage($args=false){ if(!empty($args)) return '&subpage='.strtolower($args); }
	public static function getId(){ return !empty($_GET['id'])?$_GET['id']:''; }
	public static function createId($args=false){ if(!empty($args)) return '&id='.strtolower($args); }
	public static function ReqThemeFile($file=false){ if(!empty($file)): require_once THEME_PATH.'/'.$file.'.php'; endif;  }
	public static function loadsite(){  self::ReqThemeFile('header'); self::ReqThemeFile('contents'); self::ReqThemeFile('footer'); 	}
	public static function getThemePages(){ $page=self::getFileNameBySlug(); $file=!empty($page)?$page:self::getMenuFlds(1,'file'); self::ReqThemeFile($file); }
	public static function getCurrentPageLink(){ $route=pxcore::Route(); return !empty($route)?$route:self::getMenuFlds(1,'slug'); }
	public static function getMenuFlds($id=false,$fld=false){ 
		if(!empty($id) and !empty($fld)){
			$menuItem=pxcore::get_data('navigation',' `id`='.$id);
			return !empty($menuItem)?$menuItem[0][$fld]:'';
		}
	}
	public static function getFileNameBySlug(){
        $page=self::getCurrentPageLink(); 
        if(!empty($page)):
            $menuItem=pxcore::get_data('navigation',' `slug`="'.$page.'" AND `status`=1 ');
            return !empty($menuItem)?(strtolower($menuItem[0]['file'])):self::getMenuFlds(1,'file');
        else:
            return self::getMenuFlds(1,'file');
        endif;
    }
	public static function getMenu(){
		$menu=pxcore::get_data('navigation',' `status`=1 '); $return='';
		if(!empty($menu)): $route=pxcore::Route(); $current=!empty($route)?$route:self::getMenuFlds(1,'slug');
			 foreach($menu as $key => $menua): $slug=($key == 0)?pxcore::site_url():pxcore::site_url().$menua['slug'];
				if($menua['slug'] == $current):
					$return.='<li class="nav-item"><a class="nav-link active" aria-current="page" href="'.$slug.'">'.ucwords($menua['name']).'</a></li>';
				else:
					$return.='<li class="nav-item"><a class="nav-link" aria-current="page" href="'.$slug.'">'.ucwords($menua['name']).'</a></li>';
				endif;
			 endforeach;
		endif;
		return $return;
	}
	
	/* Date processing functions */
	public static function getHospitalName(){ $single=pxcore::get_data('hospital',' `id`=1'); return !empty($single)?$single[0]['hospital_name']:'Hospital'; }
	
	/* Patients related functions*/
	public static function getPatients(){ return pxcore::get_data('patient'); }
	public static function getSinglePatient($id=false, $fld=false){
		if(!empty($id)){
			$single=pxcore::get_data('patient',' `id`='.$id);
			if(!empty($fld)){
				return !empty($single)?$single[0][$fld]:'';
			} else{
				return !empty($single)?$single[0]:[];
			}
		}
	}	
	public static function getPatientsList($args=false){
        $label=!empty($args['label'])?$args['label']:'Select Patient'; $list='<option value="">'.$label.'</option>';
        foreach(self::getPatients() as $Patient):
            if(!empty($args['selected']) and $args['selected'] == $Patient['id']):
                $list.='<option value="'.$Patient['id'].'" selected>'.ucwords($Patient['patient_name']).'</option>';
            else:
                $list.='<option value="'.$Patient['id'].'">'.ucwords($Patient['patient_name']).'</option>';
            endif;
        endforeach;
        return $list;
    }
	public static function addNewPatient($args=false){ 
		if(!empty($args['postData']['patientname']) and !empty($args['loc'])){
			//if(!empty($args['postData']['doctorname'])){
				$sql=' `test_type`="'.$args['postData']['testname'].'", `patient_name`="'.$args['postData']['patientname'].'" ';
				if(pxcore::set_data('INSERT','patient',$sql)):
					pxcore::ErrorMsg('Patient saved successfully!'); pxcore::_GoTo($args['loc']);
				else:
				   return pxcore::ServerError(' saving patient ');
			   endif;
			/*} else{
				return 'Please select doctor';
			}*/
		} else{
			return 'Please enter valid patient name';
		}
	}
	public static function updatePatient($args=false){
		if(!empty($args['postData']) and !empty($args['loc']) and !empty($args['updateId'])){
			//if(!empty($args['postData']['doctorname'])){
				$sql=' `test_type`="'.$args['postData']['testname'].'", `patient_name`="'.$args['postData']['patientname'].'" ';
				if(pxcore::set_data('UPDATE','patient',$sql, ' `id`='.$args['updateId'])):
					pxcore::ErrorMsg('Patient updated successfully!'); pxcore::_GoTo($args['loc']);
				else:
				   return pxcore::ServerError(' updating patient ');
			   endif;
			/*} else{
				return 'Please select doctor';
			}*/
		} else{
			return 'Please enter valid patient name';
		}
	}
	
	/* Doctor related functions*/
	public static function getDoctors(){ return pxcore::get_data('doctors'); }
	public static function getSingleDoctor($id=false, $fld=false){
		if(!empty($id)){
			$single=pxcore::get_data('doctors',' `id`='.$id);
			if(!empty($fld)){
				return !empty($single)?$single[0][$fld]:'';
			} else{
				return !empty($single)?$single[0]:[];
			}
		}
	}	
	public static function getDoctorsList($args=false){
        $label=!empty($args['label'])?$args['label']:'Select Doctor'; $list='<option value="">'.$label.'</option>';
        foreach(self::getDoctors() as $doctors):
            if(!empty($args['selected']) and $args['selected'] == $doctors['id']):
                $list.='<option value="'.$doctors['id'].'" selected>'.ucwords($doctors['doctor_name']).'</option>';
            else:
                $list.='<option value="'.$doctors['id'].'">'.ucwords($doctors['doctor_name']).'</option>';
            endif;
        endforeach;
        return $list;
    }
	public static function addNewDoctor($args=false){ //print_r($args);
		if(!empty($args['postData']['doctorname']) and !empty($args['loc'])){
			if(pxcore::set_data('INSERT','doctors',' `doctor_name`="'.$args['postData']['doctorname'].'" ')):
                pxcore::ErrorMsg('Doctor saved successfully!'); pxcore::_GoTo($args['loc']);
            else:
               return pxcore::ServerError(' saving doctor ');
           endif;
		} else{
			return 'Please enter valid doctor name';
		}
	}
	public static function updateDoctor($args=false){
		if(!empty($args['postData']['doctorname']) and !empty($args['loc']) and !empty($args['updateId'])){
			if(pxcore::set_data('UPDATE','doctors',' `doctor_name`="'.$args['postData']['doctorname'].'" ',' `id`='.$args['updateId'])):
                pxcore::ErrorMsg('Doctor updated successfully!'); pxcore::_GoTo($args['loc']);
            else:
               return pxcore::ServerError(' updating doctor ');
           endif;
		} else{
			return 'Please enter valid doctor name';
		}
	}
	
	/* Opreations related functions*/
	public static function getOpreations(){ return pxcore::get_data('opreations'); }
	public static function getSingleOpreation($id=false, $fld=false){
		if(!empty($id)){
			$single=pxcore::get_data('opreations',' `id`='.$id);
			if(!empty($fld)){
				return !empty($single)?$single[0][$fld]:'';
			} else{
				return !empty($single)?$single[0]:[];
			}
		}
	}	
	public static function addNewOpreation($args=false){ 
		if(!empty($args['postData']['opreationname']) and !empty($args['loc'])){
			if(!empty($args['postData']['doctorname']) and !empty($args['postData']['patientname'])){
				$sql=' `doctor`="'.$args['postData']['doctorname'].'", `patient`="'.$args['postData']['patientname'].'", `opration_name`="'.$args['postData']['opreationname'].'" ';
				if(pxcore::set_data('INSERT','opreations',$sql)):
					pxcore::ErrorMsg('Opreations saved successfully!'); pxcore::_GoTo($args['loc']);
				else:
				   return pxcore::ServerError(' saving opreation ');
			   endif;
			} else{
				return 'Please select doctor & patient';
			}
		} else{
			return 'Please enter valid operation name';
		}
	}
	public static function updateOpreation($args=false){
		if(!empty($args['postData']) and !empty($args['loc']) and !empty($args['updateId'])){
			if(!empty($args['postData']['doctorname']) and !empty($args['postData']['patientname'])){
				$sql=' `doctor`="'.$args['postData']['doctorname'].'", `patient`="'.$args['postData']['patientname'].'", `opration_name`="'.$args['postData']['opreationname'].'" ';
				if(pxcore::set_data('UPDATE','opreations',$sql, ' `id`='.$args['updateId'])):
					pxcore::ErrorMsg('Opreations updated successfully!'); pxcore::_GoTo($args['loc']);
				else:
				   return pxcore::ServerError(' updating opreation ');
			   endif;
			} else{
				return 'Please select doctor & patient';
			}
		} else{
			return 'Please enter valid operation name';
		}
	}
	
}