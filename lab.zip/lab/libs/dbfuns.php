<?php
class dbfuns
{
        private $link;
        function __construct(){ 
            $mysqlidb=new mysqli('lab.cx2kcfoqzncu.us-east-1.rds.amazonaws.com','admin','admin123','rk_lab');
            $this->link=$mysqlidb; if(!$this->link){ echo 'CONNECTION Error: '.$this->link->connect_error; }
        }
        //close database connection
        function __destruct(){  $this->closedb($this->link); }
        //get data from database tables using mysqli
        public function get_result($table=false,$where=false,$extra=false,$selectfld=false){
            $selectfld=(!empty($selectfld))?$selectfld:'*'; $ary=array();
            if(!empty($where)): 
                $sql= 'SELECT '.$selectfld.' FROM `'.$table.'` WHERE '.$where;
            else:
                $sql='SELECT '.$selectfld.' FROM `'.$table.'` '.$extra;
            endif;
            if($query=$this->link->query($sql)):
                while($result= $query->fetch_assoc()){ $ary[]=$result; }
                $query->free(); unset($query);
            endif;
            return $ary;
        }
        public function get_cresult($table=false,$selectfld=false,$aftertbl=false){
            $selectfld = (!empty($selectfld))?$selectfld:'*';
            $aftertbl = (!empty($aftertbl))?$aftertbl:' '; $ary=array();
            if(!empty($table)):
                $sql="SELECT $selectfld FROM `$table` ".$aftertbl;
                $query=$this->link->query($sql);
                while($result=$query->fetch_assoc()){ $ary[]=$result; }
                $query->free(); unset($query);
            endif;
            return $ary;
        }
        public function set_custom($qry=false){
            if(!empty($qry)): $ary=array();
               $query=$this->link->query($qry); 
               if(!empty($query) and $query->num_rows > 0):
                   while($result=$query->fetch_assoc()){ $ary[]=$result; }
                   $query->free(); unset($query);
               endif;
               return $ary;
            endif;
        }
        public function get_custom($sql=false){ $ary=array();
            if(!empty($sql)): $ary=array(); 
                $query=$this->link->query($sql);
                if(!empty($query)):
                    while($result=$query->fetch_assoc()){ $ary[]=$result; }
                    $query->free(); unset($query);
                endif;
            endif;
            return $ary;
        }
        //delete data from database tables using mysqli
        public function delete_record($table=false,$where=false){
            if(!empty($table) and !empty($where)): 
                $sql='DELETE FROM `'.$table.'` WHERE '.$where;
                return $this->link->query($sql);
            endif;
        }
        //insert and update data to database tables using mysqli
        public function set_result($fun=false,$table=false,$fields=false,$where=false){
                switch($fun){
                    case 'INSERT': 
                        $sql='INSERT INTO `'.$table.'` SET '.$fields; 
                        $this->link->query($sql); return $this->link->insert_id;
                    break;
                    case 'UPDATE': 
                       $sql='UPDATE `'.$table.'` SET '.$fields.' WHERE '.$where; return $this->link->query($sql);
                    break;
                }
        }       
        public function real_string($str=false){ return $this->link->real_escape_string($str); }
        //databse connection closing function
        private function closedb(){  $this->link->close();  }
}
